<?php namespace App\Controllers;

class Home extends BaseController
{
    public function index()
{
    $data = [
        'title' => 'Dashboard Pelelangan Ikan',
        'active_menu' => 'beranda',
        'stats' => [
            'total_transaksi' => 128,
            'total_nelayan' => 42,
            'total_bakul' => 15,
            'omset_bulanan' => 'Rp 1,2 M'
        ],
        'recent_transactions' => [
            ['id' => 'TRX-001', 'nelayan' => 'Ahmad', 'total' => 'Rp 4.250.000', 'tanggal' => '12 Mei 2024'],
            ['id' => 'TRX-002', 'nelayan' => 'Budi', 'total' => 'Rp 3.750.000', 'tanggal' => '11 Mei 2024'],
            ['id' => 'TRX-003', 'nelayan' => 'Siti', 'total' => 'Rp 5.100.000', 'tanggal' => '10 Mei 2024']
        ]
    ];
    
    return view('beranda', $data);
}
}