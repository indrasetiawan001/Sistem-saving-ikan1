<?php namespace App\Controllers;

class Main extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Sistem Saving Pelelangan Ikan'
        ];
        return view('templates/main', $data);
    }
}
