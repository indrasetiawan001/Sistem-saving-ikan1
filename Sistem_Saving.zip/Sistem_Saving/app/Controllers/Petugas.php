<?php namespace App\Controllers;

use App\Models\KarcisModel;
use App\Models\NelayanModel;
use App\Models\BakulModel;

class Petugas extends BaseController
{
    protected $karcisModel;
    
    public function __construct()
    {
        $this->karcisModel = new KarcisModel();
        $this->nelayanModel = new NelayanModel();
        $this->bakulModel = new BakulModel();
    }
    
        public function index()
    {
        die(var_dump(view('petugas/dashboard')));
        $data = [
            'title' => 'Dashboard Petugas TPI',
            'karcis' => $this->karcisModel->where('created_by', session('user_id'))->findAll()
        ];
        
        return view('petugas/dashboard.php', $data);
    }
    
    public function tambahKarcis()
    {
        if ($this->request->getMethod() === 'post') {
            $rules = [
                'no_karcis' => 'required|is_unique[tbl_karcis.no_karcis]',
                'tanggal' => 'required',
                'id_nelayan' => 'required',
                'id_bakul' => 'required',
                'jumlah_ikan' => 'required|numeric',
                'harga_per_kg' => 'required|numeric'
            ];
            
            if ($this->validate($rules)) {
                $total = $this->request->getPost('jumlah_ikan') * $this->request->getPost('harga_per_kg');
                
                $data = [
                    'no_karcis' => $this->request->getPost('no_karcis'),
                    'tanggal' => $this->request->getPost('tanggal'),
                    'id_nelayan' => $this->request->getPost('id_nelayan'),
                    'id_bakul' => $this->request->getPost('id_bakul'),
                    'jumlah_ikan' => $this->request->getPost('jumlah_ikan'),
                    'harga_per_kg' => $this->request->getPost('harga_per_kg'),
                    'total_nilai' => $total,
                    'status' => 'pending',
                    'created_by' => session('user_id')
                ];
                
                $this->karcisModel->save($data);
                return redirect()->to('/petugas')->with('message', 'Karcis berhasil ditambahkan');
            } else {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
        }
        
        $data['nelayan'] = $this->nelayanModel->findAll();
        $data['bakul'] = $this->bakulModel->findAll();
        return view('petugas/tambah_karcis', $data);
    }
}