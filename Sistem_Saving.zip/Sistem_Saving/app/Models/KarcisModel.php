<?php 

namespace App\Models;

use CodeIgniter\Model;

class KarcisModel extends Model
{
    protected $table = 'tbl_karcis';
    protected $primaryKey = 'id';
    protected $allowedFields = ['no_karcis', 'tanggal', 'id_nelayan', 'id_bakul', 'jumlah_ikan', 'harga_per_kg', 'total_nilai', 'status', 'created_by'];
}