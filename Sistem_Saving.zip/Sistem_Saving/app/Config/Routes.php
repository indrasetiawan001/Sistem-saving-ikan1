<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/', 'Home::index');
$routes->get('/', 'Beranda::index');
$routes->match(['get', 'post'], 'login', 'Home::index'); // Arahkan ke beranda sementara
$routes->get('/', 'Home::index');

$routes->get('/', function() {
    return redirect()->to('/login'); // Atau arahkan langsung ke template main
});
$routes->get('/check-session', function() {
    echo '<pre>';
    print_r(session()->get());
    echo '</pre>';
});

// Petugas TPI
$routes->group('petugas', ['filter' => 'auth:petugas_tpi'], function($routes) {
    $routes->get('/petugas', 'Petugas::index');
    $routes->get('tambah-karcis', 'Petugas::tambahKarcis');
    $routes->post('tambah-karcis', 'Petugas::tambahKarcis');
});

// Admin HNSI
$routes->group('admin', ['filter' => 'auth:admin_hnsi'], function($routes) {
    $routes->get('/', 'Admin::index');
    // tambahkan route lainnya untuk admin
});

// Kepala HNSI
$routes->group('kepala', ['filter' => 'auth:kepala_hnsi'], function($routes) {
    $routes->get('/', 'Kepala::index');
    // tambahkan route lainnya untuk kepala
});

// Nelayan/Bakul
$routes->group('member', ['filter' => 'auth:nelayan,bakul'], function($routes) {
    $routes->get('/', 'Member::index');
    // tambahkan route lainnya untuk member
});

