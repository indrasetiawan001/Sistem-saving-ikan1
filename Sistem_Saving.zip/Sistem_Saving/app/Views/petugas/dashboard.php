<?= $this->extend('templates/main') ?>

<?= $this->section('content') ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Daftar Karcis Pelelangan Ikan</h4>
            </div>
            <div class="card-body">
                <?php if (session()->getFlashdata('message')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('message') ?>
                    </div>
                <?php endif; ?>

                <a href="<?= base_url('/petugas/tambah-karcis') ?>" class="btn btn-success mb-3">
                    <i class="fas fa-plus"></i> Tambah Karcis Baru
                </a>

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>No. Karcis</th>
                                <th>Tanggal</th>
                                <th>Nelayan</th>
                                <th>Bakul</th>
                                <th>Total Nilai</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($karcis as $k): ?>
                            <tr>
                                <td><?= $k['no_karcis'] ?></td>
                                <td><?= date('d/m/Y', strtotime($k['tanggal'])) ?></td>
                                <td><?= $k['id_nelayan'] ?></td> <!-- Ganti dengan nama nelayan jika sudah ada relasi -->
                                <td><?= $k['id_bakul'] ?></td> <!-- Ganti dengan nama bakul jika sudah ada relasi -->
                                <td>Rp <?= number_format($k['total_nilai'], 0, ',', '.') ?></td>
                                <td>
                                    <span class="badge bg-<?= $k['status'] == 'approved' ? 'success' : 'warning' ?>">
                                        <?= $k['status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>